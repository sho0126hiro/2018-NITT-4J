void OnHosStart(VP_INT exinf);
void printTime(VP_INT exinf);
void primeNumber(VP_INT exinf);
void printLine(VP_INT exinf);
