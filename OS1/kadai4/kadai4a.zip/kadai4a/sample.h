void OnHosStart(VP_INT exinf);
void CYC_wupCButton(VP_INT exinf);
void checkButton(VP_INT exinf);
void CYC_wupCBK(VP_INT exinf);
void checkButtonKeep(VP_INT exinf);
void buttonHandler(VP_INT exinf);
