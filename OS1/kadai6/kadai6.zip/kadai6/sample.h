void OnHosStart(VP_INT exinf);
void taskA(VP_INT exinf);
void taskB(VP_INT exinf);
void taskC(VP_INT exinf);
void taskD(VP_INT exinf);
void mymemcpy(char *d, char *s, int size);

